var __extends = this.__extends || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    __.prototype = b.prototype;
    d.prototype = new __();
};
var Preloader = (function (_super) {
    __extends(Preloader, _super);
    function Preloader() {
        _super.call(this);
    }
    Preloader.prototype.preload = function () {
        this.load.image('logo2', 'assets/phaser.png');
    };

    Preloader.prototype.create = function () {
        this.game.state.start('MainMenu', true, false);
    };
    return Preloader;
})(Phaser.State);
//# sourceMappingURL=Preloader.js.map
