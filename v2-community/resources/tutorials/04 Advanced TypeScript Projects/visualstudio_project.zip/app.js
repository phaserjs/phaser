window.onload = function () {
    var game = new TestGame();
};
//# sourceMappingURL=app.js.map
