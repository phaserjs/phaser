
window.onload = () => {

    var game = new Castlevania.Game();

};